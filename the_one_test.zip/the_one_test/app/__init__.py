from flask import Flask
#将Flask类的实例 赋值给名为 app 的变量。这个实例成为app包的成员。
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

from config import Config
app = Flask(__name__)
app.config.from_object(Config)
# print('等会谁（哪个包或模块）在使用我：',__name__)
# print(app.config['SECRET_KEY'])

db = SQLAlchemy(app)#数据库对象
migrate = Migrate(app,db)
login = LoginManager(app)
login.login_view = 'login'

from app import routes,models#从app包中导入模块routes,models模块将定义数据库结构

